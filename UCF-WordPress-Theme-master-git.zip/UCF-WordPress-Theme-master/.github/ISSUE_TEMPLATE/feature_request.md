---
name: "\U0001F680 Feature request"
about: Suggest an idea for this theme

---

<!--
Thank you for suggesting an idea to make UCF-WordPress-Theme better.

Please provide a general summary of your feature request in the Title above, and fill in as much of the template below as you can.
-->

**Description**
<!-- Provide a detailed description of the change or addition you are proposing -->
<!-- If your feature request is related to a problem you're trying to solve, describe that here as well -->

**Why it's Important**
<!--- Why is this change important to you or your organization? -->
<!--- How can it benefit others who utilize this theme? -->

**Alternatives**
<!-- Please describe alternative solutions or features you've considered -->

**Possible Implementation**
<!--- Not required: suggest an idea for implementing addition or change -->

**Additional context**
<!-- Add any other context or screenshots related to this feature request -->

